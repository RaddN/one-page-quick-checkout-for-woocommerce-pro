jQuery(document).ready(function ($) {
    plugincydebugLog("Settings : ", onepaqucpro_rmsgValue.plugincy_all_settings);

    function fcStr(key, fallback) {
        var fc = (typeof onepaqucpro_rmsgValue !== 'undefined' && onepaqucpro_rmsgValue.floating_cart) ? onepaqucpro_rmsgValue.floating_cart : {};
        if (fc[key] !== undefined && fc[key] !== '') {
            return fc[key];
        }
        return fallback;
    }

    function formatSelectedCountLabel(count) {
        var p = typeof onepaqucpro_wc_cart_params !== 'undefined' ? onepaqucpro_wc_cart_params : {};
        var suffix = (p.txt_selected) ? p.txt_selected : 'selected';
        return String(count) + ' ' + suffix;
    }

    const checkout_popup = $('.checkout-popup');
    $isonepagewidget = (checkout_popup.length) ? checkout_popup.data('isonepagewidget') : false;
    const iframeFallbackEnabled = !!(window.onepaqucpro_rmsgValue && window.onepaqucpro_rmsgValue.popup_iframe_fallback_enabled);

    var checkoutIframe = $('<iframe>', {
        src: onepaqucpro_rmsgValue.checkout_url + '?hide_header_footer=1',
        id: 'checkout-iframe',
        frameborder: 0,
        style: 'width: 100%; min-height: 100%; height: 100%;'
    });

    function popupHasNativeCheckoutForm() {
        return $('.checkout-popup form.checkout.woocommerce-checkout').length > 0;
    }

    window.createCheckoutIframe = function () {
        if (!iframeFallbackEnabled) {
            return false;
        }

        if (!$('form.checkout.woocommerce-checkout').length && checkout_popup.length && $(".checkout-popup #checkout-form").length && !$(".checkout-popup #checkout-form #checkout-iframe").length) {
            // Show loading spinner before iframe loads
            $('.checkout-popup #checkout-form').html('<style>div#checkout-form { overflow: hidden !important; display: flex ; flex-direction: column; justify-content: center; }</style><div class="plugincy_preloader"> <svg class="plugincy_cart" role="img" aria-label="Shopping plugincy_cart line animation" viewBox="0 0 128 128" width="128px" height="128px" xmlns="http://www.w3.org/2000/svg"> <g fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="8"> <g class="plugincy_cart__track" stroke="hsla(0,10%,10%,0.1)"> <polyline points="4,4 21,4 26,22 124,22 112,64 35,64 39,80 106,80" /> <circle cx="43" cy="111" r="13" /> <circle cx="102" cy="111" r="13" /> </g> <g class="plugincy_cart__lines" stroke="currentColor"> <polyline class="plugincy_cart__top" points="4,4 21,4 26,22 124,22 112,64 35,64 39,80 106,80" stroke-dasharray="338 338" stroke-dashoffset="-338" /> <g class="plugincy_cart__wheel1" transform="rotate(-90,43,111)"> <circle class="plugincy_cart__wheel-stroke" cx="43" cy="111" r="13" stroke-dasharray="81.68 81.68" stroke-dashoffset="81.68" /> </g> <g class="plugincy_cart__wheel2" transform="rotate(90,102,111)"> <circle class="plugincy_cart__wheel-stroke" cx="102" cy="111" r="13" stroke-dasharray="81.68 81.68" stroke-dashoffset="81.68" /> </g> </g> </g> </svg> <div class="plugincy_preloader__text"> <p class="plugincy_preloader__msg">' + fcStr('preloader_msg', 'Bringing you the goods\u2026') + '</p> <p class="plugincy_preloader__msg plugincy_preloader__msg--last">' + fcStr('preloader_slow', 'This is taking long. Something\u2019s wrong.') + '</p> </div> </div>');
            $('.checkout-popup #checkout-form').append(checkoutIframe);

            $(".checkout-popup div#checkout-form").css("overflow", "hidden");

            // Remove spinner when iframe is loaded
            checkoutIframe.on('load', function () {
                $('.plugincy_preloader').remove();
            });

            checkoutIframe.on('error', function () {
                $('.checkout-popup #checkout-form').html('<p>' + fcStr('iframe_error', 'Error loading checkout. Please try again.') + '</p>');
            });
        }

        return true;
    }

    // Function to refresh iframe
    window.refreshCheckoutIframe = function () {
        if (!iframeFallbackEnabled) {
            return false;
        }

        if ($('#checkout-iframe').length) {
            $('#checkout-iframe')[0].src = $('#checkout-iframe')[0].src;
        }

        return true;
    };

    window.onepaqucproRefreshPopupCheckout = function () {
        if (!checkout_popup.length) {
            return;
        }

        if (popupHasNativeCheckoutForm()) {
            $(document.body).trigger('update_checkout');
            return;
        }

        if (iframeFallbackEnabled) {
            window.createCheckoutIframe();
            window.refreshCheckoutIframe();
        }
    };

    function clearTemporaryDrawerStyles() {
        if ($('#cart-drawer-style').length) {
            $('#cart-drawer-style').remove();
        }

        if ($('#cart-drawer2-style').length) {
            $('#cart-drawer2-style').remove();
        }
    }

    // Click event to close cart drawer and checkout popup
    $(document).click(function (event) {
        if (!$(event.target).closest('.cart-drawer, .rwc_cart-button, .checkout-popup').length) {
            closeCartAndCheckout();
        }
    });

    $(document).on('click', '.rwc_cart-button', function () {
        openCartDrawer();
    });

    // Open the cart drawer
    window.openCartDrawer = function () {
        const cartDrawer = $('.cart-drawer');
        const overlay = $('.overlay');
        clearTemporaryDrawerStyles();
        if (cartDrawer && cartDrawer.length) {
            cartDrawer.addClass('open');
            if (overlay) overlay.show();
            document.body.style.overflow = 'hidden';
        }

    };

    // Close the checkout popup
    window.closeCheckoutPopup = function () {
        closeCartAndCheckout();
    };

    // Open the checkout popup
    window.openCheckoutPopup = function () {
        if (!checkout_popup.length) {
            return;
        }

        checkout_popup.show();
        const cartDrawer = $('.cart-drawer');
        const overlay = $('.overlay');
        if (cartDrawer && cartDrawer.length) {
            cartDrawer.removeClass('open');
        }

        if (!$isonepagewidget) {
            if (overlay.length) {
                overlay.show();
            }
            document.body.style.overflow = 'hidden';
        }

        clearTemporaryDrawerStyles();
        window.onepaqucproRefreshPopupCheckout();

        if (!$('#cart-drawer-style').length) {
            $('body').append(`
                <style id="cart-drawer-style">
                    .cart-drawer {
                    opacity: 0 !important;
                    visibility: hidden !important;
                    }
                </style>
            `);
        }
    };

    // Function to close the cart drawer and checkout popup
    function closeCartAndCheckout() {
        if (!$isonepagewidget) {
            if (checkout_popup) checkout_popup.hide();
        }
        const cartDrawer = $('.cart-drawer');
        if (cartDrawer && cartDrawer.length) cartDrawer.removeClass('open');
        $('.overlay').hide(); // Hide overlay when cart is closed
        document.body.style.overflow = '';
        clearTemporaryDrawerStyles();
    }

    // Select & select all functionality

    $(document).on('change', '#select-all-items', function () {
        $('.item-checkbox').prop('checked', this.checked);
        updateSelectedCount();
    });

    // Individual item selection
    $(document).on('change', '.item-checkbox', function () {
        updateSelectedCount();
        updateSelectAllCheckbox();
    });

    // Update selected count
    function updateSelectedCount() {
        const checkedBoxes = document.querySelectorAll('.item-checkbox:checked');
        const selectedCountText = document.getElementById('selected-count-text');
        const removeSelectedButton = document.getElementById('remove-selected');
        const count = checkedBoxes.length;
        if (selectedCountText) {
            selectedCountText.textContent = formatSelectedCountLabel(count);
        }
        if (removeSelectedButton) {
            removeSelectedButton.style.display = count > 0 ? 'inline-block' : 'none';
        }
    }

    // Update select all checkbox
    function updateSelectAllCheckbox() {
        const selectAllCheckbox = document.getElementById('select-all-items');
        if (!selectAllCheckbox) {
            return;
        }
        const itemCheckboxes = document.querySelectorAll('.item-checkbox');
        const checkedBoxes = document.querySelectorAll('.item-checkbox:checked');
        selectAllCheckbox.checked = checkedBoxes.length === itemCheckboxes.length;
    }

    // Remove selected items
    $(document).on('click', '#remove-selected', function () {
        const checkedBoxes = $('.item-checkbox:checked');
        if (checkedBoxes.length === 0) return;

        const cartItemKeys = [];
        checkedBoxes.each(function () {
            const cartItemKey = $(this).data('cart-item-key');
            cartItemKeys.push(cartItemKey);
            const cartItem = $(this).closest('.cart-item');
            cartItem.addClass("removing");
            cartItem.css('transition', 'opacity 0.5s ease');
            cartItem.css('opacity', '0.5');
        });

        window.removecartitem(cartItemKeys);
    });

    // Apply coupon



    // Helper function to check applied coupons visibility

    $(document).on('click', '#apply-coupon', function () {
        const appliedCoupons = document.getElementById('applied-coupons');
        const couponInput = $('#coupon-code');
        const couponCode = couponInput.val().trim();
        if (!couponCode) return;

        setLoadingState(this, true, fcStr('applying', 'Applying\u2026'));
        showMessage(fcStr('applying_coupon', 'Applying coupon\u2026'), 'loading');

        const data = {
            action: 'apply_coupon',
            coupon_code: couponCode,
            security: onepaqucpro_rmsgValue.apply_coupon
        };

        jQuery.post(woocommerce_params.ajax_url, data, function (response) {
            setLoadingState($('#apply-coupon')[0], false, fcStr('apply_coupon', 'Apply coupon'));
            if (response.success) {
                showMessage(fcStr('coupon_applied', 'Coupon applied successfully!'), 'success');
                window.updateCartTotals(response.data);
                // Add to applied coupons list
                if (appliedCoupons) {
                    appliedCoupons.style.display = "block";
                    if (appliedCoupons.children.length <= 0) {
                        appliedCoupons.innerHTML = '<h4>' + fcStr('applied_coupons_heading', 'Applied Coupons:') + '</h4>';
                    }
                    const couponElement = document.createElement('div');
                    couponElement.className = 'applied-coupon';
                    couponElement.innerHTML = `
                        <span>${couponCode}</span>
                        <button class="remove-coupon" data-coupon="${couponCode}">${fcStr('remove', 'Remove')}</button>
                    `;
                    appliedCoupons.appendChild(couponElement);
                }

                // Clear input
                couponInput.value = '';
            } else {
                showMessage(response.data.message || fcStr('invalid_coupon', 'Invalid coupon code.'), 'error');
            }
        }).fail(function () {
            setLoadingState($('#apply-coupon')[0], false, fcStr('apply_coupon', 'Apply coupon'));
            showMessage(fcStr('error_try_again', 'Something went wrong. Please try again.'), 'error');
        });
    });

    // Add event listener to remove button (using event delegation for dynamically added buttons)

    $(document).on('click', '.remove-coupon', function (e) {
        const couponCode = this.dataset.coupon;
        removeCoupon(couponCode, this);
    });

    // Remove coupon
    function removeCoupon(couponCode, buttonElement) {
        const appliedCoupons = document.getElementById('applied-coupons');
        // Show loading state for the specific remove button
        setLoadingState(buttonElement, true, fcStr('removing', 'Removing\u2026'));
        showMessage(fcStr('removing_coupon', 'Removing coupon\u2026'), 'loading');

        const data = {
            action: 'remove_coupon',
            coupon_code: couponCode,
            security: onepaqucpro_rmsgValue.apply_coupon
        };

        jQuery.post(woocommerce_params.ajax_url, data, function (response) {
            if (response.success) {
                // Remove coupon from DOM
                const couponElement = buttonElement.parentElement;
                if (couponElement) {
                    couponElement.remove();
                }
                if (appliedCoupons.children.length <= 1) {
                    appliedCoupons.style.display = 'none'; // Hide the element
                }

                // Show success message
                showMessage(fcStr('coupon_removed', 'Coupon removed successfully!'), 'success');

                // Update cart totals
                window.updateCartTotals(response.data);
            } else {
                // Remove loading state if removal failed
                setLoadingState(buttonElement, false, fcStr('remove', 'Remove'));
                showMessage(fcStr('failed_remove_coupon', 'Failed to remove coupon. Please try again.'), 'error');
            }
        }).fail(function () {
            // Handle AJAX error
            setLoadingState(buttonElement, false, fcStr('remove', 'Remove'));
            showMessage(fcStr('error_try_again', 'Something went wrong. Please try again.'), 'error');
        });
    }

    // Helper function to set loading state on buttons
    function setLoadingState(button, isLoading, text) {
        if (isLoading) {
            button.disabled = true;
            button.classList.add('loading');
            button.textContent = text;
            // Add spinner if you have CSS for it
            // button.innerHTML = `<span class="spinner"></span> ${text}`;
        } else {
            button.disabled = false;
            button.classList.remove('loading');
            button.textContent = text;
        }
    }

    // Helper function to show messages with auto-clear
    function showMessage(message, type) {
        const couponMessage = document.getElementById('coupon-message');
        if (couponMessage) {
            couponMessage.textContent = message;
            couponMessage.className = `coupon-message ${type}`;
            couponMessage.style.display = "block";

            // Don't auto-clear loading messages
            setTimeout(() => {
                couponMessage.textContent = '';
                couponMessage.className = 'coupon-message';
                couponMessage.style.display = "none";
            }, 3000);
        }
    }

    // Update cart totals
    window.updateCartTotals = function (data) {
        $(document.body).trigger('update_checkout');
        // Update subtotal
        const subtotalElement = document.querySelector('.summary-row:not(.discount):not(.total) span:last-child');
        if (subtotalElement) {
            subtotalElement.innerHTML = data.subtotal; // Use innerHTML
        }

        // Update discount
        const discountElement = document.querySelector('.summary-row.discount');
        if (discountElement) {
            if (data.discount_total > 0) {
                discountElement.style.display = 'flex';
                discountElement.innerHTML = '<span>' + fcStr('discount', 'Discount') + '</span><span>- ' + onepaqucpro_rmsgValue.currency_symbol + ' ' + data.discount_total + '</span>';
            } else {
                discountElement.style.display = 'none';
            }
        }

        // Update total
        const totalElement = document.querySelector('.summary-row.total span:last-child');
        if (totalElement) {
            totalElement.innerHTML = data.total; // Use innerHTML
        }
    }

    $(document).on('click', '.quantity-btn', function () {
        const $input = $(this).siblings('.item-quantity');
        let currentValue = parseInt($input.val(), 10);

        if ($(this).data('action') === 'plus') {
            currentValue += 1;
        } else if ($(this).data('action') === 'minus' && currentValue > 1) {
            currentValue -= 1;
        }

        $input.val(currentValue);
        $input.trigger('change'); // Trigger the change event to use your existing code

    });
});











// variation selection handle

jQuery(function ($) {
    function getArchivePresentationDefaults($product) {
        if (!$product || !$product.length) {
            return null;
        }

        var defaults = $product.data('onepaqucproArchivePresentationDefaults');
        if (defaults) {
            return defaults;
        }

        var $price = $product.find('.price').first();
        var $image = $product.find('.astra-shop-thumbnail-wrap img, img.wp-post-image').first();

        defaults = {
            priceHtml: $price.length ? $price.html() : '',
            imageSrc: $image.attr('src') || '',
            imageSrcset: $image.attr('srcset') || '',
            imageSizes: $image.attr('sizes') || '',
        };

        $product.data('onepaqucproArchivePresentationDefaults', defaults);
        return defaults;
    }

    function normalizeVariationPresentation(variationData) {
        if (!variationData || typeof variationData !== 'object') {
            return null;
        }

        var imageData = variationData.image && typeof variationData.image === 'object' ? variationData.image : {};

        return {
            priceHtml: variationData.price_html || variationData.priceHtml || '',
            imageSrc: variationData.image_src || variationData.imageSrc || imageData.src || '',
            imageSrcset: variationData.image_srcset || variationData.imageSrcset || imageData.srcset || '',
            imageSizes: variationData.image_sizes || variationData.imageSizes || imageData.sizes || '',
        };
    }

    function updateArchiveProductPresentation($wrap, variationData) {
        var $product = $wrap && $wrap.length ? $wrap.closest('.product') : $();
        if (!$product.length) {
            return;
        }

        var defaults = getArchivePresentationDefaults($product);
        if (!defaults) {
            return;
        }

        var presentation = normalizeVariationPresentation(variationData);
        var $price = $product.find('.price').first();
        var $image = $product.find('.astra-shop-thumbnail-wrap img, img.wp-post-image').first();

        if ($price.length) {
            if (presentation && presentation.priceHtml) {
                $price.html(presentation.priceHtml);
            } else if (typeof defaults.priceHtml === 'string') {
                $price.html(defaults.priceHtml);
            }
        }

        if ($image.length) {
            var nextSrc = presentation && presentation.imageSrc ? presentation.imageSrc : defaults.imageSrc;
            if (nextSrc) {
                $image.attr('src', nextSrc);
            }

            var nextSrcset = presentation && presentation.imageSrcset ? presentation.imageSrcset : defaults.imageSrcset;
            if (nextSrcset) {
                $image.attr('srcset', nextSrcset);
            } else {
                $image.removeAttr('srcset');
            }

            var nextSizes = presentation && presentation.imageSizes ? presentation.imageSizes : defaults.imageSizes;
            if (nextSizes) {
                $image.attr('sizes', nextSizes);
            } else {
                $image.removeAttr('sizes');
            }
        }
    }

    function getSeparateVariationConfig($wrap) {
        if (!$wrap || !$wrap.length) {
            return null;
        }

        var cachedConfig = $wrap.data('onepaqucproSeparateConfig');
        if (cachedConfig) {
            return cachedConfig;
        }

        var $box = $wrap.find('.separate-attrs');
        if (!$box.length) {
            return null;
        }

        var variations = [];
        var attrKeys = [];

        try {
            variations = JSON.parse($box.find('script.var-map').text() || '[]');
        } catch (e) { }

        try {
            attrKeys = JSON.parse($box.find('script.attr-keys').text() || '[]');
        } catch (e) { }

        cachedConfig = {
            $wrap: $wrap,
            $box: $box,
            variations: variations,
            attrKeys: attrKeys
        };

        $wrap.data('onepaqucproSeparateConfig', cachedConfig);
        return cachedConfig;
    }

    function getSelectedSeparateValues($wrap) {
        var selected = {};

        $wrap.find('.var-attr-option.selected').each(function () {
            var $btn = $(this);
            var attr = $btn.data('attr');
            var value = $btn.data('value');

            if (attr && value) {
                selected[attr] = value;
            }
        });

        return selected;
    }

    function findSeparateVariationId(config, selected) {
        for (var i = 0; i < config.variations.length; i++) {
            var variation = config.variations[i];
            var isMatch = true;

            for (var k = 0; k < config.attrKeys.length; k++) {
                var attrKey = config.attrKeys[k];
                if (!selected[attrKey] || variation.attrs[attrKey] != selected[attrKey]) {
                    isMatch = false;
                    break;
                }
            }

            plugincydebugLog("possible variation id : ", variation.id);
            if (isMatch) {
                return variation.id;
            }
        }

        return '';
    }

    function findSeparateVariationData(config, variationId, selected) {
        var targetId = variationId ? String(variationId) : '';

        if (targetId) {
            for (var i = 0; i < config.variations.length; i++) {
                if (String(config.variations[i].id) === targetId) {
                    return config.variations[i];
                }
            }
        }

        if (!selected || !Object.keys(selected).length) {
            return null;
        }

        for (var j = 0; j < config.variations.length; j++) {
            var variation = config.variations[j];
            var matches = true;

            for (var k = 0; k < config.attrKeys.length; k++) {
                var attrKey = config.attrKeys[k];
                if (!selected[attrKey] || !variation.attrs || variation.attrs[attrKey] != selected[attrKey]) {
                    matches = false;
                    break;
                }
            }

            if (matches) {
                return variation;
            }
        }

        return null;
    }

    function refreshSeparateAvailability(config, selected) {
        config.attrKeys.forEach(function (attrKey) {
            config.$box.find('.var-attr-option[data-attr="' + attrKey + '"]').each(function () {
                var $option = $(this);
                var value = $option.data('value');
                var testSelection = Object.assign({}, selected);
                testSelection[attrKey] = value;

                var available = config.variations.some(function (variation) {
                    return config.attrKeys.every(function (key) {
                        return !testSelection[key] || variation.attrs[key] == testSelection[key];
                    });
                });

                if (available) {
                    $option.removeClass('disabled');
                } else {
                    $option.addClass('disabled');
                }
            });
        });
    }

    function syncSeparateVariationState($wrap) {
        var config = getSeparateVariationConfig($wrap);
        if (!config) {
            return;
        }

        var selected = getSelectedSeparateValues($wrap);
        refreshSeparateAvailability(config, selected);

        var variationId = findSeparateVariationId(config, selected);
        var variationData = findSeparateVariationData(config, variationId, selected);
        plugincydebugLog("selected: ", selected);
        plugincydebugLog("final variation id: ", variationId);

        $wrap.find('input.variation_id').val(variationId);
        $wrap.find('span.variation_id').text(variationId);
        updateArchiveProductPresentation($wrap, variationData);
    }

    // Keep overlays attached directly to .product
    $('.overlay-variations').each(function () {
        var $variations = $(this);
        var $product = $variations.closest('.product');
        if ($product.length) {
            $variations.detach().appendTo($product);
        }
    });

    // COMBINE clicks (unchanged)
    $(document).on('click', '.variation-button', function () {
        plugincydebugLog("clicked variation button combined: ", $(this));
        var $button = $(this);
        var $wrap = $button.closest('.archive-variations-container');
        var id = $button.data('id');
        var variationData = {
            price_html: $button.attr('data-price-html') || '',
            image_src: $button.attr('data-image-src') || '',
            image_srcset: $button.attr('data-image-srcset') || '',
            image_sizes: $button.attr('data-image-sizes') || '',
        };
        plugincydebugLog("variation id: ", id);
        $button.addClass('selected').siblings().removeClass('selected');
        $wrap.find('input.variation_id').val(id);
        $wrap.find('span.variation_id').text(id);
        updateArchiveProductPresentation($wrap, variationData);
    });

    $('.archive-variations-container[data-layout="separate"]').each(function () {
        syncSeparateVariationState($(this));
    });

    $(document).on('click', '.archive-variations-container[data-layout="separate"] .var-attr-option', function () {
        plugincydebugLog("clicked variation button: ", $(this));
        var $btn = $(this);

        if ($btn.hasClass('disabled')) {
            return;
        }

        $btn.closest('.var-attr-options').find('.var-attr-option').removeClass('selected');
        $btn.addClass('selected');

        syncSeparateVariationState($btn.closest('.archive-variations-container'));
    });

    window.onepaqucproInitSeparateArchiveVariations = function ($container) {
        syncSeparateVariationState($container);
        return $container;
    };
});
