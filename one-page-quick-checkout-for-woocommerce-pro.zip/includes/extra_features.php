<?php
if (! defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Add product image to WooCommerce checkout page cart items
 */
function onepaqucpro_add_product_image_to_checkout_cart_items($product_name, $cart_item, $cart_item_key)
{
    if (get_option("rmenupro_add_img_before_product") !== "1") {
        return $product_name;
    }
    // Get the product
    $product = $cart_item['data'];

    // Get product thumbnail
    $thumbnail = $product->get_image(array(50, 50));

    // Return the image followed by the product name
    return '<div class="checkout-product-item"><div class="checkout-product-image">' . $thumbnail . '</div><div class="checkout-product-name">' . esc_html($product_name) . '</div></div>';
}
add_filter('woocommerce_cart_item_name', 'onepaqucpro_add_product_image_to_checkout_cart_items', 10, 3);

/**
 * Comprehensive WooCommerce variation validation with deduplication
 * 
 * @param WC_Product $product Product object
 * @return array Validated and deduplicated variations
 */
function onepaqucpro_get_validated_variations( $product ) {
    // Skip if product is not published or is scheduled
    if ( ! $product || 'publish' !== $product->get_status() ) {
        return [];
    }

    // Get all variations (including potentially invalid ones)
    $all_variations = $product->get_available_variations();
    if ( empty( $all_variations ) ) {
        return [];
    }

    // Normalize attribute values to the slugs WooCommerce expects.
    $normalize_attribute_value = static function ( $value ) {
        if ( is_array( $value ) ) {
            return '';
        }

        if ( is_bool( $value ) ) {
            $value = $value ? 'yes' : 'no';
        }

        if ( is_numeric( $value ) ) {
            $value = (string) $value;
        } else {
            $value = trim( (string) $value );
        }

        if ( '' === $value ) {
            return '';
        }

        return function_exists( 'sanitize_title' ) ? sanitize_title( $value ) : strtolower( $value );
    };

    // Get product attributes used for variations
    $product_attributes   = $product->get_attributes();
    $variation_attributes = [];

    // Prepare attribute validation data
    foreach ( $product_attributes as $attribute_name => $attribute ) {
        if ( $attribute->get_variation() ) {
            if ( $attribute->is_taxonomy() ) {
                // Terms (slugs) for taxonomy attributes
                $terms = wc_get_product_terms(
                    $product->get_id(),
                    $attribute_name,
                    [ 'fields' => 'slugs' ]
                );

                $variation_attributes[ $attribute_name ] = [
                    'type'               => 'taxonomy',
                    'options'            => $terms,
                    'normalized_options' => array_values(
                        array_filter(
                            array_map( $normalize_attribute_value, $terms ),
                            static function ( $value ) {
                                return '' !== $value;
                            }
                        )
                    ),
                    'required'           => true,
                ];
            } else {
                // Options for custom attributes
                $options = array_map( 'trim', $attribute->get_options() );

                $variation_attributes[ $attribute_name ] = [
                    'type'               => 'custom',
                    'options'            => $options,
                    'normalized_options' => array_values(
                        array_filter(
                            array_map( $normalize_attribute_value, $options ),
                            static function ( $value ) {
                                return '' !== $value;
                            }
                        )
                    ),
                    'required'           => true,
                ];
            }
        }
    }

    // No variation attributes? just return default available variations
    if ( empty( $variation_attributes ) ) {
        return $all_variations;
    }

    $combination_map   = [];
    $combination_order = [];

    foreach ( $all_variations as $variation ) {

        $variation_id  = $variation['variation_id'];
        $variation_obj = wc_get_product( $variation_id );

        // 1. Basic checks
        if ( ! $variation_obj ) {
            continue;
        }

        // Status
        if ( 'publish' !== $variation_obj->get_status() ) {
            continue;
        }

        // Catalog visibility
        if ( 'hidden' === $variation_obj->get_catalog_visibility() ) {
            continue;
        }

        // Stock / backorder
        $stock_status       = $variation_obj->get_stock_status();
        $backorders_allowed = $variation_obj->get_backorders();

        if ( 'outofstock' === $stock_status && 'no' === $backorders_allowed ) {
            continue;
        }

        // Price
        $price = $variation_obj->get_price();
        if ( '' === $price || ! is_numeric( $price ) || $price < 0 ) {
            continue;
        }

        // Tax class does not determine whether a variation is selectable.
        // WooCommerce commonly stores "Same as parent" as `parent`; older
        // versions of this helper rejected that valid value and returned no
        // variations for otherwise purchasable variable products.

        // Shipping class
        $shipping_class_id = $variation_obj->get_shipping_class_id();
        if ( $shipping_class_id > 0 && ! term_exists( $shipping_class_id, 'product_shipping_class' ) ) {
            continue;
        }

        // Downloadable file check
        if ( $variation_obj->is_downloadable() ) {
            $files = $variation_obj->get_downloads();
            if ( empty( $files ) ) {
                continue;
            }
        }

        // 2. Normalize attribute keys and values
        //    convert "attribute_pa_cpu" => "pa_cpu"
        $raw_attributes = $variation_obj->get_attributes();
        $attributes     = [];

        foreach ( $raw_attributes as $attr_name => $attr_value ) {

            if ( 0 === strpos( $attr_name, 'attribute_' ) ) {
                $attr_name = substr( $attr_name, 10 ); // remove "attribute_"
            }

            $attributes[ $attr_name ] = $normalize_attribute_value( $attr_value );
        }

        // 3. Validate attributes against product definitions
        $is_valid = true;

        foreach ( $variation_attributes as $attr_name => $attr_data ) {
            $attr_value = isset( $attributes[ $attr_name ] ) ? $attributes[ $attr_name ] : '';

            // "any" (empty) is allowed, as long as the product has options for that attribute
            if ( '' === $attr_value ) {
                if ( empty( $attr_data['normalized_options'] ) ) {
                    $is_valid = false;
                    break;
                }
                continue;
            }

            if ( ! in_array( $attr_value, $attr_data['normalized_options'], true ) ) {
                $is_valid = false;
                break;
            }
        }

        // Missing required attributes => invalid
        if ( $is_valid ) {
            foreach ( $variation_attributes as $attr_name => $attr_data ) {
                if ( ! array_key_exists( $attr_name, $attributes ) ) {
                    $is_valid = false;
                    break;
                }
            }
        }

        if ( ! $is_valid ) {
            continue;
        }

        // 4. Expand wildcard attributes to actual combinations so we can dedupe properly.
        $values_per_attribute = [];
        $specificity          = 0;

        foreach ( $variation_attributes as $attr_name => $attr_data ) {
            $attr_value = isset( $attributes[ $attr_name ] ) ? $attributes[ $attr_name ] : '';

            if ( '' === $attr_value ) {
                $options = $attr_data['options'];
                if ( empty( $options ) ) {
                    $options = [ '' ];
                }

                $values_per_attribute[ $attr_name ] = [];

                foreach ( $options as $option ) {
                    $normalized_option = $normalize_attribute_value( $option );

                    if ( '' === $normalized_option ) {
                        continue;
                    }

                    $values_per_attribute[ $attr_name ][] = [
                        'key'  => $normalized_option,
                        'raw'  => $option,
                        'fill' => true,
                    ];
                }

                if ( empty( $values_per_attribute[ $attr_name ] ) ) {
                    $values_per_attribute[ $attr_name ][] = [
                        'key'  => '',
                        'raw'  => '',
                        'fill' => true,
                    ];
                }
            } else {
                $specificity++;
                $values_per_attribute[ $attr_name ] = [
                    [
                        'key'  => $attr_value,
                        'raw'  => $attr_value,
                        'fill' => false,
                    ],
                ];
            }
        }

        if ( empty( $values_per_attribute ) ) {
            continue;
        }

        $combinations = [ [] ];

        foreach ( $values_per_attribute as $attr_name => $possible_values ) {
            $new_combinations = [];

            foreach ( $combinations as $combination ) {
                foreach ( $possible_values as $possible_value ) {
                    $new_combination               = $combination;
                    $new_combination[ $attr_name ] = $possible_value;
                    $new_combinations[]            = $new_combination;
                }
            }

            $combinations = $new_combinations;
        }

        foreach ( $combinations as $combination_values ) {
            $key_parts = [];

            foreach ( $combination_values as $attr_name => $attr_value ) {
                $key_parts[ $attr_name ] = $attr_name . '=' . ( isset( $attr_value['key'] ) ? $attr_value['key'] : '' );
            }

            ksort( $key_parts );
            $combination_key = implode( '&', $key_parts );

            $variation_for_combo = $variation;
            $variation_for_combo['attributes'] = isset( $variation_for_combo['attributes'] ) && is_array( $variation_for_combo['attributes'] )
                ? $variation_for_combo['attributes']
                : [];

            foreach ( $combination_values as $attr_name => $attr_value ) {
                if ( empty( $attr_value['fill'] ) ) {
                    continue;
                }

                $attr_key = 0 === strpos( $attr_name, 'attribute_' ) ? $attr_name : 'attribute_' . $attr_name;
                $variation_for_combo['attributes'][ $attr_key ] = isset( $attr_value['raw'] ) ? $attr_value['raw'] : '';
            }

            if ( ! isset( $combination_map[ $combination_key ] ) ) {
                $combination_order[]                = $combination_key;
                $combination_map[ $combination_key ] = [
                    'specificity' => $specificity,
                    'variation'   => $variation_for_combo,
                ];
                continue;
            }

            if ( $specificity >= $combination_map[ $combination_key ]['specificity'] ) {
                $combination_map[ $combination_key ] = [
                    'specificity' => $specificity,
                    'variation'   => $variation_for_combo,
                ];
            }
        }
    }

    if ( empty( $combination_order ) ) {
        return $all_variations;
    }

    $result = [];
    foreach ( $combination_order as $combination_key ) {
        if ( isset( $combination_map[ $combination_key ] ) ) {
            $result[] = $combination_map[ $combination_key ]['variation'];
        }
    }

    return $result;
}

function onepaqucpro_cart_item_variation_switch_enabled()
{
    return function_exists('onepaqucpro_premium_feature')
        && onepaqucpro_premium_feature()
        && '1' === (string) get_option('rmenupro_cart_checkout_variation_switch', 0);
}

function onepaqucpro_get_cart_item_readd_data($cart_item)
{
    $reserved_keys = array(
        'key',
        'product_id',
        'variation_id',
        'variation',
        'quantity',
        'data',
        'data_hash',
        'line_tax_data',
        'line_subtotal',
        'line_subtotal_tax',
        'line_total',
        'line_tax',
    );

    $cart_item_data = array();

    foreach ((array) $cart_item as $key => $value) {
        if (in_array($key, $reserved_keys, true)) {
            continue;
        }

        $cart_item_data[$key] = $value;
    }

    return $cart_item_data;
}

function onepaqucpro_get_normalized_cart_item_variation_attributes($cart_item)
{
    $variation = array();

    if (!empty($cart_item['variation']) && is_array($cart_item['variation'])) {
        foreach ($cart_item['variation'] as $attribute_key => $attribute_value) {
            if ($attribute_value === '' || $attribute_value === null) {
                continue;
            }

            $variation[onepaqucpro_normalize_attr_key($attribute_key)] = onepaqucpro_normalize_attr_value($attribute_value);
        }
    }

    if (!empty($cart_item['variation_id'])) {
        $variation_product = wc_get_product(absint($cart_item['variation_id']));

        if ($variation_product instanceof WC_Product_Variation) {
            foreach ((array) $variation_product->get_variation_attributes() as $attribute_key => $attribute_value) {
                if ($attribute_value === '' || $attribute_value === null) {
                    continue;
                }

                $normalized_key = onepaqucpro_normalize_attr_key($attribute_key);
                if (empty($variation[$normalized_key])) {
                    $variation[$normalized_key] = onepaqucpro_normalize_attr_value($attribute_value);
                }
            }
        }
    }

    return $variation;
}

function onepaqucpro_get_cart_item_variation_editor_data($cart_item)
{
    if (!onepaqucpro_cart_item_variation_switch_enabled() || !function_exists('onepaqucpro_get_archive_variation_popup_data')) {
        return array();
    }

    $product_id = !empty($cart_item['product_id']) ? absint($cart_item['product_id']) : 0;
    $product = $product_id ? wc_get_product($product_id) : false;

    if (!($product instanceof WC_Product_Variable)) {
        return array();
    }

    $editor_data = onepaqucpro_get_archive_variation_popup_data($product);
    if (empty($editor_data['attributes']) || empty($editor_data['variations'])) {
        return array();
    }

    $selected_variation_id = !empty($cart_item['variation_id']) ? (string) absint($cart_item['variation_id']) : '';
    $selected_attributes = array();

    foreach (onepaqucpro_get_normalized_cart_item_variation_attributes($cart_item) as $attribute_key => $attribute_value) {
        $selected_attributes[str_replace('attribute_', '', $attribute_key)] = $attribute_value;
    }

    if ($selected_variation_id !== '') {
        foreach ((array) $editor_data['variations'] as $variation) {
            if (!isset($variation['id']) || (string) $variation['id'] !== $selected_variation_id || empty($variation['attrs']) || !is_array($variation['attrs'])) {
                continue;
            }

            foreach ($variation['attrs'] as $attribute_key => $attribute_value) {
                if (empty($selected_attributes[$attribute_key])) {
                    $selected_attributes[$attribute_key] = (string) $attribute_value;
                }
            }

            break;
        }
    }

    $attr_keys = !empty($editor_data['attr_keys']) && is_array($editor_data['attr_keys'])
        ? array_values($editor_data['attr_keys'])
        : array_keys((array) $editor_data['attributes']);

    if (empty($attr_keys)) {
        return array();
    }

    $selected_attributes = array_intersect_key($selected_attributes, array_flip($attr_keys));
    $editor_data['attr_keys'] = $attr_keys;
    $editor_data['selected_variation_id'] = $selected_variation_id;
    $editor_data['selected_attributes'] = $selected_attributes;

    if (count($editor_data['variations']) < 2) {
        $only_variation = reset($editor_data['variations']);

        if (!is_array($only_variation) || empty($only_variation['id']) || (string) $only_variation['id'] === $selected_variation_id) {
            return array();
        }
    }

    return $editor_data;
}

function onepaqucpro_get_cart_item_variation_editor_html($cart_item, $cart_item_key, $context = 'checkout')
{
    $editor_data = onepaqucpro_get_cart_item_variation_editor_data($cart_item);
    if (empty($editor_data['attributes']) || empty($editor_data['variations'])) {
        return '';
    }

    $selected_attributes = !empty($editor_data['selected_attributes']) && is_array($editor_data['selected_attributes'])
        ? $editor_data['selected_attributes']
        : array();
    $context = sanitize_html_class((string) $context);
    $toggle_label = esc_attr__('Change options', 'one-page-quick-checkout-for-woocommerce-pro');
    $update_button_text = function_exists('onepaqucpro_get_floating_cart_text')
        ? onepaqucpro_get_floating_cart_text('rmenu_floating_cart_variation_update_text', __('Update', 'one-page-quick-checkout-for-woocommerce-pro'))
        : __('Update', 'one-page-quick-checkout-for-woocommerce-pro');
    $cancel_button_text = function_exists('onepaqucpro_get_floating_cart_text')
        ? onepaqucpro_get_floating_cart_text('rmenu_floating_cart_variation_cancel_text', __('Cancel', 'one-page-quick-checkout-for-woocommerce-pro'))
        : __('Cancel', 'one-page-quick-checkout-for-woocommerce-pro');

    ob_start();
    ?>
    <div class="onepaqucpro-cart-variation-editor onepaqucpro-cart-variation-editor--<?php echo esc_attr($context); ?>" data-cart-item-key="<?php echo esc_attr($cart_item_key); ?>">
        <button type="button" class="onepaqucpro-cart-variation-editor__toggle" aria-expanded="false" aria-label="<?php echo $toggle_label; ?>" title="<?php echo $toggle_label; ?>">
            <svg class="onepaqucpro-cart-variation-editor__switch-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" aria-hidden="true" focusable="false">
                <path class="onepaqucpro-cart-variation-editor__switch-icon-line" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="square" stroke-linejoin="miter" stroke-miterlimit="2" d="M3 17V7h11"></path>
                <path fill="currentColor" d="M14 5.25 16.75 7 14 8.75z"></path>
                <path class="onepaqucpro-cart-variation-editor__switch-icon-line" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="square" stroke-linejoin="miter" stroke-miterlimit="2" d="M21 7v10H10"></path>
                <path fill="currentColor" d="M10 15.25 7.25 17 10 18.75z"></path>
            </svg>
            <span class="screen-reader-text"><?php esc_html_e('Change options', 'one-page-quick-checkout-for-woocommerce-pro'); ?></span>
        </button>
        <div class="onepaqucpro-cart-variation-editor__panel" hidden>
            <div class="onepaqucpro-cart-variation-editor__fields">
                <?php foreach ((array) $editor_data['attributes'] as $attribute_key => $attribute_data) : ?>
                    <?php
                    $attribute_label = !empty($attribute_data['label']) ? (string) $attribute_data['label'] : wc_attribute_label($attribute_key);
                    $selected_value = isset($selected_attributes[$attribute_key]) ? (string) $selected_attributes[$attribute_key] : '';
                    ?>
                    <label class="onepaqucpro-cart-variation-editor__field">
                        <span class="onepaqucpro-cart-variation-editor__label"><?php echo esc_html($attribute_label); ?></span>
                        <select class="onepaqucpro-cart-variation-editor__select" data-variation-attr="<?php echo esc_attr($attribute_key); ?>">
                            <option value=""><?php echo esc_html(sprintf(__('Select %s', 'one-page-quick-checkout-for-woocommerce-pro'), $attribute_label)); ?></option>
                            <?php foreach ((array) ($attribute_data['options'] ?? array()) as $option) : ?>
                                <?php
                                $option_slug = isset($option['slug']) ? (string) $option['slug'] : '';
                                $option_label = isset($option['label']) ? (string) $option['label'] : $option_slug;
                                ?>
                                <option value="<?php echo esc_attr($option_slug); ?>" <?php selected($selected_value, $option_slug); ?>>
                                    <?php echo esc_html($option_label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                <?php endforeach; ?>
            </div>
            <div class="onepaqucpro-cart-variation-editor__actions">
                <button type="button" class="onepaqucpro-cart-variation-editor__apply" disabled>
                    <?php echo esc_html($update_button_text); ?>
                </button>
                <button type="button" class="onepaqucpro-cart-variation-editor__cancel">
                    <?php echo esc_html($cancel_button_text); ?>
                </button>
            </div>
            <p class="onepaqucpro-cart-variation-editor__feedback" aria-live="polite"></p>
        </div>
        <div class="onepaqucpro-cart-variation-editor__data" hidden data-editor-info="<?php echo esc_attr(wp_json_encode($editor_data)); ?>"></div>
    </div>
    <?php

    return ob_get_clean();
}

function onepaqucpro_append_checkout_cart_item_variation_editor($product_name, $cart_item, $cart_item_key)
{
    return $product_name;
}
add_filter('woocommerce_cart_item_name', 'onepaqucpro_append_checkout_cart_item_variation_editor', 30, 3);

function onepaqucpro_render_cart_page_variation_editor($cart_item, $cart_item_key)
{
    if (!onepaqucpro_cart_item_variation_switch_enabled() || !function_exists('is_cart') || !is_cart()) {
        return;
    }

    echo onepaqucpro_get_cart_item_variation_editor_html($cart_item, $cart_item_key, 'cart');
}
add_action('woocommerce_after_cart_item_name', 'onepaqucpro_render_cart_page_variation_editor', 20, 2);

function onepaqucpro_append_checkout_quantity_variation_editor($html, $cart_item, $cart_item_key)
{
    if (!onepaqucpro_cart_item_variation_switch_enabled()) {
        return $html;
    }

    if (!function_exists('is_checkout') || !is_checkout()) {
        return $html;
    }

    $editor_html = onepaqucpro_get_cart_item_variation_editor_html($cart_item, $cart_item_key, 'checkout-inline');
    if ($editor_html === '') {
        return $html;
    }

    return '<div class="onepaqucpro-checkout-qty-row">' . $html . $editor_html . '</div>';
}
add_filter('woocommerce_checkout_cart_item_quantity', 'onepaqucpro_append_checkout_quantity_variation_editor', 20, 3);



// add a random product in cart

if (get_option('rmenupro_at_one_product_cart', 0)) {
    add_action('template_redirect', 'onepaqucpro_add_random_product_if_cart_empty');
}

function onepaqucpro_add_random_product_if_cart_empty()
{

    // If cart is empty
    if (WC()->cart->is_empty()) {

        // Get one random product ID
        $random_product = wc_get_products(array(
            'status'    => 'publish',
            'limit'     => 1,
            'orderby'   => 'rand',
            'return'    => 'ids',
            'type'      => 'simple', // Change to 'variable' if needed
        ));

        if (!empty($random_product)) {
            WC()->cart->add_to_cart($random_product[0], 1);
        }

        // Set a flag in local storage via JavaScript to indicate a random product was added
        add_action('wp_footer', function () {
?>
            <script>
                try {
                    localStorage.setItem('random_product_added', '1');
                } catch (e) {}
            </script>
        <?php
        });
    } else {
        add_action('wp_footer', function () {
        ?>
            <script>
                try {
                    localStorage.removeItem('random_product_added');
                } catch (e) {}
            </script>
        <?php
        });
    }
}

if (get_option('rmenupro_disable_cart_page', 0)) {
    add_action('template_redirect', 'disable_cart_page_redirect');
    function disable_cart_page_redirect()
    {
        if (is_cart()) {
            wp_redirect(wc_get_checkout_url());
            exit;
        }
    }
}

if (get_option('rmenupro_link_product', 0)) {
    add_filter('woocommerce_cart_item_name', 'onepaqucpro_link_product_name_on_checkout', 10, 3);
    function onepaqucpro_link_product_name_on_checkout($product_name, $cart_item, $cart_item_key)
    {
        // Only apply on the checkout page
        if (is_checkout()) {
            $product = $cart_item['data'];
            $product_link = get_permalink($product->get_id());
            $product_name = sprintf('<a href="%s">%s</a>', esc_url($product_link), $product_name);
        }
        return $product_name;
    }
}




/**
 * Add variation selection buttons to product archive pages
 */
/**
 * Add variation selection buttons to product archive pages using woocommerce_loop_add_to_cart_link
 */
if (get_option('rmenupro_variation_show_archive', 1)  && (get_option("rmenupro_wc_direct_checkout_position", "after_add_to_cart") === "after_add_to_cart" || get_option("rmenupro_wc_direct_checkout_position", "after_add_to_cart") === "bottom_add_to_cart" || get_option("rmenupro_wc_direct_checkout_position", "after_add_to_cart") === "before_add_to_cart" || get_option("rmenupro_wc_direct_checkout_position", "after_add_to_cart") === "replace_add_to_cart")) {
    global $onepaqucpro_variation_buttons_on_archive;
    $onepaqucpro_variation_buttons_on_archive = array();
    add_filter('woocommerce_loop_add_to_cart_link', 'onepaqucpro_add_variation_buttons_to_loop', 100, 2);
    new onepaqucpro_add_variation_buttons_on_archive();
} else {
    new onepaqucpro_add_variation_buttons_on_archive();
}

class onepaqucpro_add_variation_buttons_on_archive
{
    private $is_btn_add_hook_works;
    /**
     * Constructor
     */
    public function __construct()
    {
        if (get_option('rmenupro_variation_show_archive', 1)) {
            $this->add_variation_buttons_on_archive();
            $this->is_btn_add_hook_works = false;
        }
    }

    public function add_variation_buttons_on_archive()
    {
        $position = get_option("rmenupro_wc_direct_checkout_position", "after_product");
        if ($position === 'after_add_to_cart' || $position === 'before_add_to_cart' || $position === 'bottom_add_to_cart' || $position === 'replace_add_to_cart') {
            $position = 'after_product';
        }

        switch ($position) {
            case 'overlay_thumbnail':
            case 'overlay_thumbnail_hover':
            case 'after_product':
                add_action('woocommerce_after_shop_loop_item', array($this, 'onepaquc_variation_buttons'), 110);
                break;
            case 'after_product_title':
                add_action('woocommerce_shop_loop_item_title', array($this, 'onepaquc_variation_buttons'), 14);
                break;
            case 'before_product_title':
                add_action('woocommerce_shop_loop_item_title', array($this, 'onepaquc_variation_buttons'), 8);
                break;
            case 'after_product_excerpt':
                add_action('woocommerce_after_shop_loop_item_title', array($this, 'onepaquc_variation_buttons'), 8);
                break;
            case 'after_product_rating':
                add_action('woocommerce_after_shop_loop_item_title', array($this, 'onepaquc_variation_buttons'), 6);
                break;
            case 'after_product_price':
                add_action('woocommerce_after_shop_loop_item_title', array($this, 'onepaquc_variation_buttons'), 15);
                break;
        }
    }

    public function onepaquc_variation_buttons()
    {
        global $product;

        global $onepaqucpro_variation_buttons_on_archive;

        $product_id = $product->get_id();

        static $loop_counter = 0;
        $loop_counter++;
        $context_key = $product_id . '_' . $loop_counter;

        if (!$product || !$product->is_type('variable')) {
            return;
        }

        if (isset($onepaqucpro_variation_buttons_on_archive[$context_key])) {
            return;
        }

        $available_variations = onepaqucpro_get_validated_variations( $product );

        if (empty($available_variations)) {
            return;
        }

        $onepaqucpro_variation_buttons_on_archive[$context_key] = true;

        $position = get_option("rmenupro_wc_direct_checkout_position", "after_product");
        $layout       = get_option('rmenu_variation_layout', 'separate'); // 'combine' | 'separate'
        $show_titles  = (bool) get_option('rmenu_show_variation_title', 0);

        $container_class = 'archive-variations-container';
        if (in_array($position, ['overlay_thumbnail', 'overlay_thumbnail_hover'], true)) {
            $container_class .= ' overlay-variations';
        }
        if (in_array($position, ['after_product'], true)) {
            $container_class .= ' bottom-48';
        }

        echo '<a href="#"></a><div class="' . esc_attr($container_class) . '" data-layout="' . esc_attr($layout) . '">';

        if ($layout === 'combine') {
            foreach ($available_variations as $variation) {
                $vid = $variation['variation_id'];

                // Build options per attribute (expand "Any" to options ASSIGNED to this product only)
                $attr_options = []; // [attr_key => [ ['slug'=>..., 'label'=>...], ... ]]
                foreach ($variation['attributes'] as $attribute_name => $attribute_value) {
                    $attr_key = function_exists('onepaqucpro_resolve_attribute_taxonomy')
                        ? onepaqucpro_resolve_attribute_taxonomy($attribute_name, $product)
                        : str_replace('attribute_', '', $attribute_name);

                    // Specific value chosen -> just that one
                    if ($attribute_value !== '') {
                        $slug  = $attribute_value;
                        $label = function_exists('onepaqucpro_get_variation_attribute_label')
                            ? onepaqucpro_get_variation_attribute_label($attr_key, $slug, $product)
                            : $slug;
                        $attr_options[$attr_key][] = ['slug' => $slug, 'label' => $label];
                        continue;
                    }

                    // "Any ..." chosen -> expand to options that are ASSIGNED on THIS product
                    $attribute_definition = function_exists('onepaqucpro_find_product_variation_attribute_definition')
                        ? onepaqucpro_find_product_variation_attribute_definition($product, $attr_key)
                        : array(
                            'key' => $attr_key,
                            'attribute' => isset($product->get_attributes()[$attr_key]) ? $product->get_attributes()[$attr_key] : null,
                        );
                    if (!empty($attribute_definition['key'])) {
                        $attr_key = $attribute_definition['key'];
                    }
                    if (!empty($attribute_definition['attribute'])) {
                        /** @var WC_Product_Attribute $pa */
                        $pa = $attribute_definition['attribute'];

                        if ($pa->is_taxonomy()) {
                            // taxonomy attribute: options are term IDs
                            $term_ids = (array) $pa->get_options();
                            $taxonomy = function_exists('onepaqucpro_resolve_attribute_taxonomy') ? onepaqucpro_resolve_attribute_taxonomy($attr_key, $product) : $attr_key;
                            if (!empty($term_ids)) {
                                $terms = get_terms([
                                    'taxonomy'   => $taxonomy,
                                    'hide_empty' => false,
                                    'include'    => $term_ids,
                                ]);
                                if (!is_wp_error($terms) && !empty($terms)) {
                                    foreach ($terms as $term) {
                                        $attr_options[$attr_key][] = [
                                            'slug'  => $term->slug,
                                            'label' => $term->name,
                                        ];
                                    }
                                }
                            }
                        } else {
                            // custom (non-taxonomy) attribute: options are raw strings
                            $values = (array) $pa->get_options();
                            foreach ($values as $val) {
                                $val = (string) $val;
                                $attr_options[$attr_key][] = [
                                    'slug'  => function_exists('onepaqucpro_normalize_attr_value') ? onepaqucpro_normalize_attr_value($val) : sanitize_title($val),
                                    'label' => function_exists('onepaqucpro_decode_attribute_component') ? onepaqucpro_decode_attribute_component($val) : $val,
                                ];
                            }
                        }
                    }
                }

                // If for some reason we have no options, skip this variation
                if (empty($attr_options)) {
                    continue;
                }

                // Cartesian product across attributes to produce concrete button labels
                $combinations = [[]]; // each combo: [ attr_key => ['slug'=>..., 'label'=>...] ]
                foreach ($attr_options as $key => $opts) {
                    $next = [];
                    foreach ($combinations as $combo) {
                        foreach ($opts as $opt) {
                            $tmp = $combo;
                            $tmp[$key] = $opt;
                            $next[] = $tmp;
                        }
                    }
                    $combinations = $next;
                }

                $variation_price_html = isset($variation['price_html']) ? (string) $variation['price_html'] : '';
                $variation_image_src = '';
                $variation_image_srcset = '';
                $variation_image_sizes = '';
                if (!empty($variation['image']) && is_array($variation['image'])) {
                    $variation_image_src = isset($variation['image']['src']) ? (string) $variation['image']['src'] : '';
                    $variation_image_srcset = isset($variation['image']['srcset']) ? (string) $variation['image']['srcset'] : '';
                    $variation_image_sizes = isset($variation['image']['sizes']) ? (string) $variation['image']['sizes'] : '';
                }

                // Render one button per concrete combination (store attrs for JS if needed)
                foreach ($combinations as $combo) {
                    $labels = [];
                    $attrs  = [];
                    foreach ($combo as $k => $opt) {
                        $labels[]  = $opt['label'];
                        $attrs['attribute_' . $k] = $opt['slug'];
                    }

                    echo '<button type="button" class="variation-button" data-id="' . esc_attr($vid) . '" data-attrs="' . esc_attr(wp_json_encode($attrs)) . '" data-price-html="' . esc_attr($variation_price_html) . '" data-image-src="' . esc_attr($variation_image_src) . '" data-image-srcset="' . esc_attr($variation_image_srcset) . '" data-image-sizes="' . esc_attr($variation_image_sizes) . '">'
                        . esc_html(implode(' / ', $labels))
                        . '</button>';
                }
            }

            // Keep the hidden input as before
            echo '<input type="hidden" class="variation_id" value="">';
        } else {
            // ---------- SEPARATE (group by attribute) ----------
            $attributes_terms   = []; // attr_key => ['label'=>..., 'terms'=> [ slug => label ]]
            $attr_keys_indexed  = []; // seen keys
            $variations_for_js  = []; // [{id, attrs:{attr=>slug}}]

            foreach ($available_variations as $variation) {
                $vid       = $variation['variation_id'];
                $var_attrs = [];

                foreach ($variation['attributes'] as $attribute_name => $attribute_value) {
                    $attr_key   = function_exists('onepaqucpro_resolve_attribute_taxonomy')
                        ? onepaqucpro_resolve_attribute_taxonomy($attribute_name, $product)
                        : str_replace('attribute_', '', $attribute_name); // e.g., pa_color or custom
                    $slug       = $attribute_value;
                    if ($slug === '') {
                        $attribute_definition = function_exists('onepaqucpro_find_product_variation_attribute_definition')
                            ? onepaqucpro_find_product_variation_attribute_definition($product, $attr_key)
                            : array(
                                'key' => $attr_key,
                                'attribute' => isset($product->get_attributes()[$attr_key]) ? $product->get_attributes()[$attr_key] : null,
                            );
                        if (!empty($attribute_definition['key'])) {
                            $attr_key = $attribute_definition['key'];
                        }

                        if (!empty($attribute_definition['attribute'])) {
                            /** @var WC_Product_Attribute $pa */
                            $pa = $attribute_definition['attribute'];

                            if ($pa->is_taxonomy()) {
                                // taxonomy attribute: options are term IDs
                                $term_ids = (array) $pa->get_options();
                                $taxonomy = function_exists('onepaqucpro_resolve_attribute_taxonomy') ? onepaqucpro_resolve_attribute_taxonomy($attr_key, $product) : $attr_key;
                                if (!empty($term_ids)) {
                                    $terms = get_terms([
                                        'taxonomy'   => $taxonomy,
                                        'hide_empty' => false,
                                        'include'    => $term_ids,
                                    ]);
                                    if (!is_wp_error($terms) && !empty($terms)) {
                                        foreach ($terms as $term) {
                                            if (!isset($attributes_terms[$attr_key])) {
                                                $attributes_terms[$attr_key] = [
                                                    'label' => function_exists('onepaqucpro_get_variation_attribute_taxonomy_label') ? onepaqucpro_get_variation_attribute_taxonomy_label($attr_key, $product) : wc_attribute_label($attr_key, $product),
                                                    'terms' => [],
                                                ];
                                            }
                                            $attributes_terms[$attr_key]['terms'][$term->slug] = $term->name;
                                        }
                                    }
                                }
                            } else {
                                // custom (non-taxonomy) attribute: options are raw strings
                                $values = (array) $pa->get_options();
                                if (!empty($values)) {
                                    if (!isset($attributes_terms[$attr_key])) {
                                        $attributes_terms[$attr_key] = [
                                            'label' => function_exists('onepaqucpro_get_variation_attribute_taxonomy_label') ? onepaqucpro_get_variation_attribute_taxonomy_label($attr_key, $product) : (wc_attribute_label($attr_key, $product) ?: ucfirst(str_replace('pa_', '', $attr_key))),
                                            'terms' => [],
                                        ];
                                    }
                                    foreach ($values as $val) {
                                        $val = (string) $val;
                                        $val_slug = function_exists('onepaqucpro_normalize_attr_value') ? onepaqucpro_normalize_attr_value($val) : sanitize_title($val);
                                        $attributes_terms[$attr_key]['terms'][$val_slug] = function_exists('onepaqucpro_decode_attribute_component') ? onepaqucpro_decode_attribute_component($val) : $val;
                                    }
                                }
                            }
                        }
                        continue;
                    }

                    $attr_label = function_exists('onepaqucpro_get_variation_attribute_taxonomy_label')
                        ? onepaqucpro_get_variation_attribute_taxonomy_label($attr_key, $product)
                        : wc_attribute_label($attr_key, $product);
                    $value_label = function_exists('onepaqucpro_get_variation_attribute_label')
                        ? onepaqucpro_get_variation_attribute_label($attr_key, $slug, $product)
                        : $slug;

                    if (!isset($attributes_terms[$attr_key])) {
                        $attributes_terms[$attr_key] = [
                            'label' => $attr_label ?: ucfirst(str_replace('pa_', '', $attr_key)),
                            'terms' => []
                        ];
                    }
                    $attributes_terms[$attr_key]['terms'][$slug] = $value_label;

                    $var_attrs[$attr_key] = $slug;
                    $attr_keys_indexed[$attr_key] = true;
                }

                $variation_image = (!empty($variation['image']) && is_array($variation['image'])) ? $variation['image'] : [];
                $variations_for_js[] = [
                    'id' => (string) $vid,
                    'attrs' => $var_attrs,
                    'price_html' => isset($variation['price_html']) ? (string) $variation['price_html'] : '',
                    'image_src' => isset($variation_image['src']) ? (string) $variation_image['src'] : '',
                    'image_srcset' => isset($variation_image['srcset']) ? (string) $variation_image['srcset'] : '',
                    'image_sizes' => isset($variation_image['sizes']) ? (string) $variation_image['sizes'] : '',
                ];
            }

            $attr_keys = array_keys($attr_keys_indexed);

            // Container that carries JSON safely (no HTML-entity headaches)
            echo '<div class="separate-attrs">';
            echo '<script type="application/json" class="var-map">' . wp_json_encode($variations_for_js) . '</script>';
            echo '<script type="application/json" class="attr-keys">' . wp_json_encode($attr_keys) . '</script>';

            foreach ($attributes_terms as $attr_key => $info) {
                echo '<div class="var-attr-group" data-attr="' . esc_attr($attr_key) . '">';

                $title_class = 'var-attr-title';
                if (!$show_titles) {
                    $title_class .= ' var-attr-title--archive-hidden';
                }

                echo '<span class="' . esc_attr($title_class) . '">' . esc_html($info['label']) . ':</span> ';

                echo '<div class="var-attr-options">';
                foreach ($info['terms'] as $slug => $label) {
                    echo '<button type="button" class="var-attr-option" data-attr="' . esc_attr($attr_key) . '" data-value="' . esc_attr($slug) . '">' . esc_html($label) . '</button>';
                }
                echo '</div></div>';
            }

            echo '</div>'; // .separate-attrs

            // Hidden + visible
            echo '<input type="hidden" class="variation_id" value="">';
        }

        echo '</div>'; // container
    }
}

function onepaqucpro_add_variation_buttons_to_loop($link, $product)
{
    global $onepaqucpro_variation_buttons_on_archive;
    $product_id = $product->get_id();

    static $loop_counter = 0;
    $loop_counter++;
    $context_key = $product_id . '_' . $loop_counter;

    if (!$product || !$product->is_type('variable') || $product->is_type("grouped")) {
        return $link;
    }

    if (isset($onepaqucpro_variation_buttons_on_archive[$context_key])) {
        return $link;
    }

    $onepaqucpro_variation_buttons_on_archive[$context_key] = true;

    $available_variations = onepaqucpro_get_validated_variations( $product );

    if (empty($available_variations)) {
        return $link;
    }

    $layout      = get_option('rmenu_variation_layout', 'separate'); // 'combine' | 'separate'
    $show_titles = (bool) get_option('rmenu_show_variation_title', 0);

    ob_start();

    echo '<div class="archive-variations-container" data-layout="' . esc_attr($layout) . '">';

    if ($layout === 'combine') {
        foreach ($available_variations as $variation) {
            $vid = $variation['variation_id'];

            // Build options per attribute (expand "Any" to options ASSIGNED to this product only)
            $attr_options = []; // [attr_key => [ ['slug'=>..., 'label'=>...], ... ]]
            foreach ($variation['attributes'] as $attribute_name => $attribute_value) {
                $attr_key = function_exists('onepaqucpro_resolve_attribute_taxonomy')
                    ? onepaqucpro_resolve_attribute_taxonomy($attribute_name, $product)
                    : str_replace('attribute_', '', $attribute_name);

                // Specific value chosen -> just that one
                if ($attribute_value !== '') {
                    $slug  = $attribute_value;
                    $label = function_exists('onepaqucpro_get_variation_attribute_label')
                        ? onepaqucpro_get_variation_attribute_label($attr_key, $slug, $product)
                        : $slug;
                    $attr_options[$attr_key][] = ['slug' => $slug, 'label' => $label];
                    continue;
                }

                // "Any ..." chosen -> expand to options that are ASSIGNED on THIS product
                $attribute_definition = function_exists('onepaqucpro_find_product_variation_attribute_definition')
                    ? onepaqucpro_find_product_variation_attribute_definition($product, $attr_key)
                    : array(
                        'key' => $attr_key,
                        'attribute' => isset($product->get_attributes()[$attr_key]) ? $product->get_attributes()[$attr_key] : null,
                    );
                if (!empty($attribute_definition['key'])) {
                    $attr_key = $attribute_definition['key'];
                }
                if (!empty($attribute_definition['attribute'])) {
                    /** @var WC_Product_Attribute $pa */
                    $pa = $attribute_definition['attribute'];

                    if ($pa->is_taxonomy()) {
                        // taxonomy attribute: options are term IDs
                        $term_ids = (array) $pa->get_options();
                        $taxonomy = function_exists('onepaqucpro_resolve_attribute_taxonomy') ? onepaqucpro_resolve_attribute_taxonomy($attr_key, $product) : $attr_key;
                        if (!empty($term_ids)) {
                            $terms = get_terms([
                                'taxonomy'   => $taxonomy,
                                'hide_empty' => false,
                                'include'    => $term_ids,
                            ]);
                            if (!is_wp_error($terms) && !empty($terms)) {
                                foreach ($terms as $term) {
                                    $attr_options[$attr_key][] = [
                                        'slug'  => $term->slug,
                                        'label' => $term->name,
                                    ];
                                }
                            }
                        }
                    } else {
                        // custom (non-taxonomy) attribute: options are raw strings
                        $values = (array) $pa->get_options();
                        foreach ($values as $val) {
                            $val = (string) $val;
                            $attr_options[$attr_key][] = [
                                'slug'  => function_exists('onepaqucpro_normalize_attr_value') ? onepaqucpro_normalize_attr_value($val) : sanitize_title($val),
                                'label' => function_exists('onepaqucpro_decode_attribute_component') ? onepaqucpro_decode_attribute_component($val) : $val,
                            ];
                        }
                    }
                }
            }

            // If for some reason we have no options, skip this variation
            if (empty($attr_options)) {
                continue;
            }

            // Cartesian product across attributes to produce concrete button labels
            $combinations = [[]]; // each combo: [ attr_key => ['slug'=>..., 'label'=>...] ]
            foreach ($attr_options as $key => $opts) {
                $next = [];
                foreach ($combinations as $combo) {
                    foreach ($opts as $opt) {
                        $tmp = $combo;
                        $tmp[$key] = $opt;
                        $next[] = $tmp;
                    }
                }
                $combinations = $next;
            }

            $variation_price_html = isset($variation['price_html']) ? (string) $variation['price_html'] : '';
            $variation_image_src = '';
            $variation_image_srcset = '';
            $variation_image_sizes = '';
            if (!empty($variation['image']) && is_array($variation['image'])) {
                $variation_image_src = isset($variation['image']['src']) ? (string) $variation['image']['src'] : '';
                $variation_image_srcset = isset($variation['image']['srcset']) ? (string) $variation['image']['srcset'] : '';
                $variation_image_sizes = isset($variation['image']['sizes']) ? (string) $variation['image']['sizes'] : '';
            }

            // Render one button per concrete combination (store attrs for JS if needed)
            foreach ($combinations as $combo) {
                $labels = [];
                $attrs  = [];
                foreach ($combo as $k => $opt) {
                    $labels[]  = $opt['label'];
                    $attrs['attribute_' . $k] = $opt['slug'];
                }

                echo '<button type="button" class="variation-button" data-id="' . esc_attr($vid) . '" data-attrs="' . esc_attr(wp_json_encode($attrs)) . '" data-price-html="' . esc_attr($variation_price_html) . '" data-image-src="' . esc_attr($variation_image_src) . '" data-image-srcset="' . esc_attr($variation_image_srcset) . '" data-image-sizes="' . esc_attr($variation_image_sizes) . '">'
                    . esc_html(implode(' / ', $labels))
                    . '</button>';
            }
        }

        // Keep the hidden input as before
        echo '<input type="hidden" class="variation_id" value="">';
    } else {
        $attributes_terms   = [];
        $attr_keys_indexed  = [];
        $variations_for_js  = [];

        foreach ($available_variations as $variation) {
            $vid       = $variation['variation_id'];
            $var_attrs = [];

            foreach ($variation['attributes'] as $attribute_name => $attribute_value) {
                $attr_key   = function_exists('onepaqucpro_resolve_attribute_taxonomy')
                    ? onepaqucpro_resolve_attribute_taxonomy($attribute_name, $product)
                    : str_replace('attribute_', '', $attribute_name);
                $slug       = $attribute_value;
                if ($slug === '') {
                    $attribute_definition = function_exists('onepaqucpro_find_product_variation_attribute_definition')
                        ? onepaqucpro_find_product_variation_attribute_definition($product, $attr_key)
                        : array(
                            'key' => $attr_key,
                            'attribute' => isset($product->get_attributes()[$attr_key]) ? $product->get_attributes()[$attr_key] : null,
                        );
                    if (!empty($attribute_definition['key'])) {
                        $attr_key = $attribute_definition['key'];
                    }

                    if (!empty($attribute_definition['attribute'])) {
                        /** @var WC_Product_Attribute $pa */
                        $pa = $attribute_definition['attribute'];

                        if ($pa->is_taxonomy()) {
                            // taxonomy attribute: options are term IDs
                            $term_ids = (array) $pa->get_options();
                            $taxonomy = function_exists('onepaqucpro_resolve_attribute_taxonomy') ? onepaqucpro_resolve_attribute_taxonomy($attr_key, $product) : $attr_key;
                            if (!empty($term_ids)) {
                                $terms = get_terms([
                                    'taxonomy'   => $taxonomy,
                                    'hide_empty' => false,
                                    'include'    => $term_ids,
                                ]);
                                if (!is_wp_error($terms) && !empty($terms)) {
                                    foreach ($terms as $term) {
                                        if (!isset($attributes_terms[$attr_key])) {
                                            $attributes_terms[$attr_key] = [
                                                'label' => function_exists('onepaqucpro_get_variation_attribute_taxonomy_label') ? onepaqucpro_get_variation_attribute_taxonomy_label($attr_key, $product) : wc_attribute_label($attr_key, $product),
                                                'terms' => [],
                                            ];
                                        }
                                        $attributes_terms[$attr_key]['terms'][$term->slug] = $term->name;
                                    }
                                }
                            }
                        } else {
                            // custom (non-taxonomy) attribute: options are raw strings
                            $values = (array) $pa->get_options();
                            if (!empty($values)) {
                                if (!isset($attributes_terms[$attr_key])) {
                                    $attributes_terms[$attr_key] = [
                                        'label' => function_exists('onepaqucpro_get_variation_attribute_taxonomy_label') ? onepaqucpro_get_variation_attribute_taxonomy_label($attr_key, $product) : (wc_attribute_label($attr_key, $product) ?: ucfirst(str_replace('pa_', '', $attr_key))),
                                        'terms' => [],
                                    ];
                                }
                                foreach ($values as $val) {
                                    $val = (string) $val;
                                    $val_slug = function_exists('onepaqucpro_normalize_attr_value') ? onepaqucpro_normalize_attr_value($val) : sanitize_title($val);
                                    $attributes_terms[$attr_key]['terms'][$val_slug] = function_exists('onepaqucpro_decode_attribute_component') ? onepaqucpro_decode_attribute_component($val) : $val;
                                }
                            }
                        }
                    }
                    continue;
                }

                $attr_label = function_exists('onepaqucpro_get_variation_attribute_taxonomy_label')
                    ? onepaqucpro_get_variation_attribute_taxonomy_label($attr_key, $product)
                    : wc_attribute_label($attr_key, $product);
                $value_label = function_exists('onepaqucpro_get_variation_attribute_label')
                    ? onepaqucpro_get_variation_attribute_label($attr_key, $slug, $product)
                    : $slug;

                if (!isset($attributes_terms[$attr_key])) {
                    $attributes_terms[$attr_key] = [
                        'label' => $attr_label ?: ucfirst(str_replace('pa_', '', $attr_key)),
                        'terms' => []
                    ];
                }
                $attributes_terms[$attr_key]['terms'][$slug] = $value_label;

                $var_attrs[$attr_key] = $slug;
                $attr_keys_indexed[$attr_key] = true;
            }

            $variation_image = (!empty($variation['image']) && is_array($variation['image'])) ? $variation['image'] : [];
            $variations_for_js[] = [
                'id' => (string) $vid,
                'attrs' => $var_attrs,
                'price_html' => isset($variation['price_html']) ? (string) $variation['price_html'] : '',
                'image_src' => isset($variation_image['src']) ? (string) $variation_image['src'] : '',
                'image_srcset' => isset($variation_image['srcset']) ? (string) $variation_image['srcset'] : '',
                'image_sizes' => isset($variation_image['sizes']) ? (string) $variation_image['sizes'] : '',
            ];
        }

        $attr_keys = array_keys($attr_keys_indexed);

        echo '<div class="separate-attrs">';
        echo '<script type="application/json" class="var-map">' . wp_json_encode($variations_for_js) . '</script>';
        echo '<script type="application/json" class="attr-keys">' . wp_json_encode($attr_keys) . '</script>';

        foreach ($attributes_terms as $attr_key => $info) {
            echo '<div class="var-attr-group" data-attr="' . esc_attr($attr_key) . '">';

            $title_class = 'var-attr-title';
            if (!$show_titles) {
                $title_class .= ' var-attr-title--archive-hidden';
            }

            echo '<span class="' . esc_attr($title_class) . '">' . esc_html($info['label']) . ':</span> ';

            echo '<div class="var-attr-options">';
            foreach ($info['terms'] as $slug => $label) {
                echo '<button type="button" class="var-attr-option" data-attr="' . esc_attr($attr_key) . '" data-value="' . esc_attr($slug) . '">' . esc_html($label) . '</button>';
            }
            echo '</div></div>';
        }

        echo '</div>'; // .separate-attrs

        echo '<input type="hidden" class="variation_id" value="">';
    }

    echo '</div>'; // container

    return ob_get_clean() . $link;
}

if (get_option('rmenupro_wc_hide_select_option', 0)) {
    // Add custom CSS for .product_type_variable in the footer
    add_action('wp_footer', 'add_custom_css_for_variable_products');
    function add_custom_css_for_variable_products()
    {
        if (is_product() || is_shop() || is_product_category() || is_product_tag()) {
            echo '<style>
            .product_type_variable {
                display: none !important;
            }
        </style>';
        }
    }
}




// Change WooCommerce checkout layout based on onepaqucpro_checkout_layout option
if (function_exists('onepaqucpro_premium_feature') && onepaqucpro_premium_feature()) {
    add_action('wp_head', 'apply_checkout_layout_styles');
}

function apply_checkout_layout_styles()
{
    $layout = get_option('onepaqucpro_checkout_layout', 'two_column');


    switch ($layout) {
        case 'one_column':
            echo '
                <style>
                @media (min-width: 768px) {
                    .onepagecheckoutwidget  form.checkout.woocommerce-checkout {
                        flex-direction: column;
                    }
                    .onepagecheckoutwidget  div#customer_details,.onepagecheckoutwidget  div#order_review {
                        width: 100% !important;
                        margin: 0 auto;
                    }
                }
                </style>
                ';
            break;

        case 'product_first':
            echo '
                <style>
                @media (min-width: 768px) {
                    .onepagecheckoutwidget  form.checkout.woocommerce-checkout{
                        display: flex;
                        flex-direction: column;
                        gap: 20px;
                    }
                    .onepagecheckoutwidget .woocommerce-checkout .col2-set {
                            width: 100% !important;
                            margin: 0 !important;
                        }
                    .onepagecheckoutwidget  .woocommerce-checkout>table.shop_table.woocommerce-checkout-review-order-table {
                            width: 100% !important;
                            float: none !important;
                            margin: 0 auto !important;
                        }
                    .onepagecheckoutwidget  tr.cart_item td.product-name {
                        display: flex;
                        padding: 12px !important;
                        gap: 10px;
                    }
                    .onepagecheckoutwidget  tr td.product-total,.onepagecheckoutwidget  tr.cart-subtotal td, .onepagecheckoutwidget  tr.order-total td {
                        padding-left: 20px !important;
                    }
                    .onepagecheckoutwidget  .payment_box p {
                        padding: 20px;
                    }
                    
                }
                </style>
                ';
        ?>
            <script>
                jQuery(document).ready(function($) {
                    function moveOrderReview() {
                        if ($('.onepagecheckoutwidget  #order_review_heading').length && $('.onepagecheckoutwidget  table.shop_table.woocommerce-checkout-review-order-table').length && !$('.onepagecheckoutwidget  .woocommerce-checkout>table.shop_table.woocommerce-checkout-review-order-table').length) {
                            var orderReviewHeading = $('.onepagecheckoutwidget  #order_review_heading').detach();
                            var orderReview = $('.onepagecheckoutwidget  table.shop_table.woocommerce-checkout-review-order-table').detach();
                            $('.onepagecheckoutwidget  .woocommerce-checkout').prepend(orderReview).prepend(orderReviewHeading);
                            orderReview.css('margin-bottom', '30px');
                            orderReviewHeading.css('margin-bottom', '10px');
                        }
                    }

                    // Initial load
                    moveOrderReview();

                    // After AJAX updates
                    $(document.body).on('updated_checkout', function() {
                        moveOrderReview();
                    });
                });
            </script>
<?php
            break;

        case 'two_column':
        default:
            echo '
                <style>
                @media (min-width: 768px) {
                    .onepagecheckoutwidget form.woocommerce-checkout{
                        display: flex;
                        gap: 40px;
                    }
                    .onepagecheckoutwidget #customer_details,.onepagecheckoutwidget #order_review {
                        width: 48% !important;
                        margin: 0 !important;
                    }
                    // .onepagecheckoutwidget #order_review_heading {
                    //     display: none;
                    // }
                }
                </style>
                ';
            break;
    }
}
if (function_exists('onepaqucpro_premium_feature') && onepaqucpro_premium_feature()) {
    // Alternative method using body class for more targeted CSS
    add_filter('body_class', 'onepaqucpro_add_checkout_layout_body_class');
}

function onepaqucpro_add_checkout_layout_body_class($classes)
{
    if (is_checkout()) {
        $layout = get_option('onepaqucpro_checkout_layout', 'two_column');
        $classes[] = 'checkout-layout-' . $layout;
    }
    return $classes;
}


add_filter('woocommerce_post_class', 'onepaqucpro_add_non_purchasable_product_class', 10, 2);

function onepaqucpro_add_non_purchasable_product_class($classes, $product)
{
    // Check if product object exists
    if (! is_object($product)) {
        $product = wc_get_product(get_the_ID());
    }

    // Check if product is not purchasable
    if ($product && ! $product->is_purchasable()) {
        $classes[] = 'plugincy-not-purchaseable';
    }

    return $classes;
}
